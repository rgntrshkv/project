import flask as flsk
import configparser as cp
import game_of_life as gl

config = cp.ConfigParser()
config.read('config.ini')
p_host = config['DEFAULT']['host']
p_port = config['DEFAULT']['port']

app = flsk.Flask(__name__)

@app.route('/')
def index():
    gl.GameOfLife(25,25)
    return flsk.render_template('index.html')

@app.route('/live')
def live(GOL = gl.GameOfLife(25,25)):
    GOL.counter+=1
    if GOL.counter > 1:
        GOL.form_new_generation()
    return flsk.render_template('live.html', GOL = GOL)

if __name__ == "__main__":
    app.run(host = p_host, port = p_port, debug = 1)